<?php
  $useremail='booksred-shop@yandex.ru';
  $username='booksred-shop';
  $password='Books25.05.2021';
?>