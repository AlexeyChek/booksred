<?php
  require_once 'parts/header.php';

  $now = 3;
?>

  <section class="main">
    <div class="container main__container">
      <?php
        require_once 'parts/nav.php';
      ?>
      <div class="about">
        <h1 class="title">контакты</h1>
        <div class="about__text">
          <p class="about__p">
            Если у вас возникли вопросы напишите нам на почту 
            <a href="mailto:orchid@gmail.com" class="contact-link">orchid@gmail.com</a>
          </p>
          <p class="about__p">
            Позвоните в службу поддержки:
          </p>
          <p class="about__p">
            Москва: <a href="tel:+74540097070" class="contact-link">+ 7 (454) 009-70-70</a><br>
            Санкт-Петербург: <a href="tel:+78775004545" class="contact-link">+7 (877) 500-45-45</a><br>
            Регионы: <a href="tel:+78002347000" class="contact-link">8 (800) 234-70-00</a> (звонок бесплатный)
          </p>
        </div>
        <!-- /.about__text -->
      </div>
      <!-- /.about -->
    </div>
    <!-- /.container main__container -->
  </section>
  <!-- /.main -->
</body>

</html>