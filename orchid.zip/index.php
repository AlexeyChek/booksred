<?php
  require_once 'parts/header.php';
?>

<section class="main">
  <div class="container main__container">
    <?php
      require_once 'parts/nav.php';
    ?>
    <div class="breadcrumb">
      <a ></a>
    </div>
    <div class="goods">
      <h1 class="title index-title">Все&nbsp;товары
        <? if ($curentCategory) { ?>
          <img src="img/icon-next.svg" alt="иконка: далее" class="title-image">
          <? echo $cat['name_rus'];
          } ?>
      </h1>
      <? foreach ($goods as $good) { ?>
        <div class="good">
          <div class="good__image">
            <img src="img/<? echo $good['image'] ?>" alt="<? echo $good['title'] ?>" class="good-image">
            <div class="good__popup popup">
              <form action="actions/add.php" method="POST" class="popup__button">
                <input type="hidden" name="id" value="<? echo $good['id'] ?>">
                <button type="submit" class="popup__title">В корзину
                  <span class="popup__price"><span class="price"><? echo $good['price'] ?></span>&#8381;</span>
                </button>
              </form>
            </div>
          </div>
          <div class="good__descriptions">
            <h2 class="good__title"><? echo $good['title'] ?></h2>
            <h3 class="good__title">Характеристики</h3>
            <? foreach (json_decode($good['options'], true) as $option => $value) { ?>
              <p class="good__option">
                <span class="good__option-title"><? echo $option ?>: </span>
                <span><? echo $value ?></span>
              </p>
            <? } ?>
          </div>
        </div>
        <!-- /.good -->
      <? } ?>
    </div>
    <!-- /.goods -->
  </div>
  <!-- /.container main__container -->
</section>
<!-- /.main -->
</body>

</html>