<?php

$connect = new PDO('mysql:host=a366108.mysql.mchost.ru; dbname=a366108_1; charset: utf8', 'a366108_1', '86gnG568fFW3');